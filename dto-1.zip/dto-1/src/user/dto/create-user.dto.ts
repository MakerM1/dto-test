import { IsEmail, IsEnum, IsInt, IsNotEmpty, IsNumber, IsPhoneNumber, IsString, Max, MaxLength, Min, MinLength, isString, min } from "class-validator";

export class CreateUserDto {
    @IsString()
    @MinLength(3)
    @MaxLength(15)
    firstName: string

    @IsString()
    @MinLength(3)
    @MaxLength(15)
    lastName: string

    @IsEmail()
    email: string

    @IsInt()
    @Min(12)
    @Max(65)
    age: number

    @IsPhoneNumber()
    phone: string

    @IsEnum(['male', 'female'])
    gender: string
}
