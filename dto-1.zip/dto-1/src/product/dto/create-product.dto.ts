import { IsArray, IsNumber, IsPositive, IsString, IsUrl, MaxLength, MinLength } from "class-validator";

export class CreateProductDto {
    @IsString()
    @MinLength(3)
    @MaxLength(255)
    title: string

    @IsNumber()
    @IsPositive()
    price: number

    @IsString()
    @MinLength(150)
    description: string

    @IsArray()
    @IsString({ each: true })
    colors: string[]

    @IsUrl()
    @IsString()
    image: string
}
