import { Type } from "class-transformer";
import { IsArray, IsDate, IsDateString, IsString, MaxLength, MinLength, ValidateNested, isArray } from "class-validator";
import { CreateUserDto } from "src/user/dto/create-user.dto";

export class CreateMeetingDto {
    @IsString()
    @MinLength(3)
    @MaxLength(255)
    title: string

    @IsDateString()
    date: string

    @ValidateNested()
    @Type(() => CreateUserDto)
    mentor: CreateUserDto

    @IsArray()
    @ValidateNested({each: true})
    @Type(() => CreateUserDto)
    students: CreateUserDto[]
}
