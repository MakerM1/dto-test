export class Meeting {}
